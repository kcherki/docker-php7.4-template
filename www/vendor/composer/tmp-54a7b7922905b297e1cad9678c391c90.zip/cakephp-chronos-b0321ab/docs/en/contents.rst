.. toctree::
    :maxdepth: 2
    :caption: CakePHP Chronos

    /index
    /2-4-upgrade-guide

    API <https://api.cakephp.org/chronos>
