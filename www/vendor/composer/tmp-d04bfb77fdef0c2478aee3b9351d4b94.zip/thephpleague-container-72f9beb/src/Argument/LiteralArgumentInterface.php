<?php

declare(strict_types=1);

namespace League\Container\Argument;

interface LiteralArgumentInterface extends ArgumentInterface
{
}
