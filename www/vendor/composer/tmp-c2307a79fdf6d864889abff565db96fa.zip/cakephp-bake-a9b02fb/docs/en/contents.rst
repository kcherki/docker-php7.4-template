.. toctree::
    :maxdepth: 2
    :caption: CakePHP Bake

    /index
    /usage
    /development
